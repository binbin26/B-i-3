﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace Bài3
{
    public partial class CalculatorForm : Form
    {
        string currentInput = "";
        string expression = "";
        bool isResultShown = false;

        public CalculatorForm()
        {
            InitializeComponent();

            // Gán sự kiện cho các nút số và dấu chấm
            foreach (Control c in this.Controls)
            {
                if (c is Button && c.Name.StartsWith("btn"))
                {
                    if (char.IsDigit(c.Text[0]) || c.Text == ".")
                        c.Click += Number_Click;
                }
            }

            // Gán sự kiện cho toán tử
            btnAdd.Click += Operator_Click;
            btnSub.Click += Operator_Click;
            btnMul.Click += Operator_Click;
            btnDiv.Click += Operator_Click;

            // Gán sự kiện cho các nút đặc biệt
            btnEqual.Click += BtnEqual_Click;
            btnCE.Click += BtnCE_Click;
            btnC.Click += BtnC_Click;

            txtDisplay.Text = " ";
            txtDisplay.ReadOnly = true;
        }

        private void Number_Click(object sender, EventArgs e)
        {
            Button btn = (Button)sender;

            if (isResultShown)
            {
                expression = "";
                currentInput = "";
                isResultShown = false;
                txtDisplay.Text = "";
            }

            if (btn.Text == "." && currentInput.Contains("."))
                return;

            currentInput += btn.Text;
            txtDisplay.Text += btn.Text;
        }

        private void Operator_Click(object sender, EventArgs e)
        {
            Button btn = (Button)sender;
            string op = btn.Text;

            if (string.IsNullOrEmpty(currentInput) && expression.Length > 0 &&
                "+-*/".Contains(expression[expression.Length - 1].ToString()))
            {
                // Thay toán tử cuối nếu bị nhấn trùng
                expression = expression.Substring(0, expression.Length - 1) + op;
                txtDisplay.Text = expression;
                return;
            }

            if (!string.IsNullOrEmpty(currentInput))
            {
                expression += currentInput;
                currentInput = "";
            }

            expression += op;
            txtDisplay.Text = expression;
        }

        private void BtnEqual_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(currentInput))
            {
                expression += currentInput;
            }

            try
            {
                var result = new System.Data.DataTable().Compute(expression, null);
                txtDisplay.Text = expression + " = " + result.ToString();
                currentInput = result.ToString();
                expression = "";
                isResultShown = true;
            }
            catch
            {
                txtDisplay.Text = "ERROR";
                currentInput = "";
                expression = "";
            }
        }

        private void BtnCE_Click(object sender, EventArgs e)
        {
            currentInput = "";
            if (expression.Length > 0 && !"+-*/".Contains(expression[expression.Length - 1].ToString()))
            {
                expression = expression.Substring(0, expression.Length - currentInput.Length);
            }
            txtDisplay.Text = expression;
        }

        private void BtnC_Click(object sender, EventArgs e)
        {
            currentInput = "";
            expression = "";
            txtDisplay.Text = "0";
        }
    }
}
